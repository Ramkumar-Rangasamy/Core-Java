import java.util.*;

public class HashsetExample{

 public static void main(String[] args){

    Set<String> org = new HashSet<>();
    
     		     org.add("Maruti Swift");
                org.add("Maruti Wagon");
                org.add("Hyundai Creta");
                org.add(" ");
                org.add("woodpecker");
                org.add("Mahindra XUV500");
                org.add("Mahindra XUV500");
                org.add("Toyota Fortuner.");

   
     Iterator itr = org.iterator();
       
       while(itr.hasNext()){
           
          System.out.println(itr.next());

       }


      //	 System.out.println(org.get(4));  // not using

            System.out.println(org.size());

 }


}